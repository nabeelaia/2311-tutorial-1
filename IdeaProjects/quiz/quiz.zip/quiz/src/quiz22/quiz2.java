package quiz22;
import java.io.IOException;
public class quiz2 {

    public static void Method1(){
        Classquiz2 obj = new Classquiz2();
        Rectangle Obj=new Rectangle(12.34, 25.86);
        System.out.println(" The area of a rectangle with side lengths as "+obj.shortSide+" and "+obj.longSide+", is "+obj.area()+".");
    }


}


