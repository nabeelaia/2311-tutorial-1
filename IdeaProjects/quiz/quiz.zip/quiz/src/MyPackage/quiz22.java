package MyPackage;
public class quiz22 {
    public static void main(String[] args) {
        double shortSide = 12.34;
        double longSide = 25.86;
        double area = 12.34 * 25.86;
        System.out.println(" The area of a rectangle with side lengths as "+shortSide+" and "+longSide+", is "+ area+".");

    }}