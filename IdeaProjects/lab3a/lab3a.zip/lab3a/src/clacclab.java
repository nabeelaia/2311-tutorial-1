import java.util.Scanner;
public class clacclab {
    public static void main(String[] args) {
        System.out.println("This program creates a discount chart for the store. HST-GST is accounted 13%.");
        System.out.println("all discount prices after tax are rounded to 0.5");
        Scanner sc= new Scanner(System.in);
        System.out.println("Enter the title of the discount chart");
        String title = sc.nextLine();
        Scanner two = new Scanner(System.in);
        System.out.println("please enter the minimum price tag between .49 and .99");
      double min = sc.nextDouble();
        Scanner input = new Scanner(System.in);
        int price = (int) min;



}


    }












