public class LAB01A {
    public static void main(String[] args) {
    System.out.print("My name is Nabeela Ansari");
        System.out.println("My student number is "+"219730662"+ ".");
        System.out.println("the remainder of my student number divided by 1021 is "+(219730662 % 1021 ));



}



    }