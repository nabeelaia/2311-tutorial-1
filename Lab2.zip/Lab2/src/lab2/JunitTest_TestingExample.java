package lab2;

import static org.junit.Assert.*;



import org.junit.Test;
import org.junit.rules.Timeout;
import org.junit.runners.MethodSorters;
import org.junit.FixMethodOrder;
import org.junit.Rule;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class JunitTest_TestingExample {

	@Rule
	public Timeout globalTimeout = Timeout.seconds(1);

	
	@Test
	public void test1() {
		
		assertEquals("The function should give 1800 points in this situation", 1800, TestingExample.RewardPoints(1100, 500));
	}
	
	@Test
	 public void test2() {

		assertEquals("The function should give 1800 points in this situation", 1800, TestingExample.RewardPoints(1100, 500));
		
	}
	
	
}
